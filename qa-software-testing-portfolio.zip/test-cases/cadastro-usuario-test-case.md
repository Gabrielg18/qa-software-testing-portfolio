# Caso de Teste: Cadastro de Usuário

**ID:** TC002  
**Funcionalidade:** Cadastro  
**Pré-condição:** Nenhuma  
**Passos:**
1. Acessar a página de cadastro
2. Preencher todos os campos obrigatórios
3. Clicar em "Cadastrar"

**Resultado Esperado:** Mensagem de sucesso exibida e redirecionamento para login  
**Status:** Passou
# Caso de Teste: Login

**ID:** TC001  
**Funcionalidade:** Login de usuário  
**Pré-condição:** Usuário cadastrado no sistema  
**Passos:**
1. Acessar a página de login
2. Inserir e-mail válido
3. Inserir senha correta
4. Clicar em "Entrar"

**Resultado Esperado:** Usuário é redirecionado para o dashboard com sucesso  
**Status:** Passou
# Checklist de Testes Exploratórios - App E-commerce

- [x] Login com dados válidos
- [x] Login com dados inválidos
- [x] Navegação entre páginas
- [x] Adicionar produto ao carrinho
- [x] Finalizar compra com sucesso
- [ ] Mensagens de erro visíveis
- [ ] Funcionalidade de busca
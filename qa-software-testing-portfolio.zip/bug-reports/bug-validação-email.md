# Bug Report: Validação de e-mail

**ID:** BR002  
**Resumo:** Sistema aceita e-mails inválidos  
**Passos para reproduzir:**
1. Acessar cadastro
2. Inserir "usuario@teste" como e-mail
3. Submeter formulário

**Resultado esperado:** Mensagem de erro de validação  
**Resultado obtido:** Cadastro realizado com sucesso  
**Gravidade:** Média
# Bug Report: Erro ao fazer login

**ID:** BR001  
**Resumo:** Sistema não reconhece senha válida  
**Passos para reproduzir:**
1. Acessar tela de login
2. Digitar e-mail e senha corretos
3. Clicar em "Entrar"

**Resultado esperado:** Acesso permitido  
**Resultado obtido:** Mensagem de erro: "Senha incorreta"  
**Gravidade:** Alta
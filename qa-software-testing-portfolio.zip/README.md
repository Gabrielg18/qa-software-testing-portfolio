# Portfólio de Testes de Software (QA)

Este repositório contém exemplos de testes manuais e exploratórios realizados em projetos simulados, com o objetivo de demonstrar minhas habilidades na área de Quality Assurance.

## O que você encontrará aqui:
- Casos de teste organizados
- Relatórios de bugs realistas
- Testes exploratórios com checklist
- Plano de testes baseado em metodologia ágil

## Ferramentas utilizadas:
- Trello (simulação de board de tarefas)
- Jira (modelo de bug reports)
- Markdown para documentação
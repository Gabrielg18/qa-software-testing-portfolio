# Guia de Uso do Repositório

1. Acesse a pasta "test-cases" para visualizar os casos de teste.
2. Verifique "bug-reports" para exemplos de bugs encontrados.
3. Consulte "exploratory-testing" para listas de verificação.
4. A pasta "docs" contém documentação geral do projeto.
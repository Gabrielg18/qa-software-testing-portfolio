# Plano de Testes

**Objetivo:** Garantir a qualidade da aplicação de e-commerce  
**Escopo:** Funcionalidades principais (login, cadastro, compra)  
**Tipos de Teste:** Funcional, Exploratório, Regressão  
**Ferramentas:** Jira, Trello  
**Equipe:** 1 QA Júnior (Gabriel Azevedo)